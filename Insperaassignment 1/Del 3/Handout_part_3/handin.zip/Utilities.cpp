#include "Utilities.h"

string toGreek(string sentence)
{
    // BEGIN: 2a

    // Write your answer to assignment 2a here, between the // BEGIN: 2a
    // and // END: 2a comments. Remove the code that is already there.

    (void)sentence;
    return "";
    
    // END: 2a
}

vector<vector<string>> loadSvada()
{
    // BEGIN: 2b

    // Write your answer to assignment 2b here, between the // BEGIN: 2b
    // and // END: 2b comments. Remove the code that is already there.

    return vector<vector<string>>{};

    // END: 2b
}

string svadaGenerator(vector<vector<string>> svadaVec)
{
    // BEGIN: 2c1

    // Write your answer to assignment 2c1 here, between the // BEGIN: 2c1
    // and // END: 2c1 comments. Remove the code that is already there.

    (void)svadaVec;
    return "";
    
    // END: 2c1
}